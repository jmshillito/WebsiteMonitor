#!/usr/bin/env python3
"""Generate the ICT365 visual school website activity dashboard PDF from JSON data."""
import json
import sys
from pathlib import Path
from reportlab.lib.pagesizes import landscape, A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader

try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None


SKILL_DIR = Path(__file__).resolve().parents[1]
DEFAULT_LOGO = SKILL_DIR / "assets" / "ict365-logo.png"


def draw_report(data, output_path):
    schools = [
        (
            str(s["school"]),
            int(s["views"]),
            str(s.get("view_growth", "")),
            int(s["clicks"]),
            str(s.get("click_growth", "")),
        )
        for s in data["schools"]
    ]
    title = data.get("title", "Schools Website Activity Report")
    period = data.get("period", "")
    source_label = data.get("source_label", "Uploaded Looker Studio report")
    takeaway_4 = str(data.get("takeaway_4", "")).strip()
    logo_path = Path(data.get("logo_path", DEFAULT_LOGO))
    if not logo_path.is_absolute():
        logo_path = SKILL_DIR / logo_path

    W, H = landscape(A4)
    c = canvas.Canvas(str(output_path), pagesize=landscape(A4))

    navy = colors.HexColor("#12355B")
    teal = colors.HexColor("#43BCCD")
    teal_soft = colors.HexColor("#E9F7F7")
    gold = colors.HexColor("#F6C85F")
    gold_soft = colors.HexColor("#F8D98A")
    green = colors.HexColor("#1A936F")
    red = colors.HexColor("#C0392B")
    dark = colors.HexColor("#243447")
    grey = colors.HexColor("#6C757D")
    light_grey = colors.HexColor("#F4F7FA")
    line = colors.HexColor("#D9E2EC")
    bar_bg = colors.HexColor("#EDF2F7")

    def rounded_rect(x, y, w, h, fill, stroke=None, radius=10, lw=1):
        c.setFillColor(fill)
        c.setStrokeColor(stroke if stroke else fill)
        c.setLineWidth(lw)
        c.roundRect(x, y, w, h, radius, fill=1, stroke=1 if stroke else 0)

    def label(text, x, y, size=9, color=dark, bold=False, align="left"):
        c.setFillColor(color)
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        if align == "center":
            c.drawCentredString(x, y, text)
        elif align == "right":
            c.drawRightString(x, y, text)
        else:
            c.drawString(x, y, text)

    def fmt(n):
        return f"{n:,}"

    def growth_color(value, neutral_zero=False):
        value = str(value)
        if "No data" in value:
            return grey
        if value.strip().startswith("-"):
            return red
        if neutral_zero and value.strip() in {"0.0%", "+0.0%"}:
            return grey
        return green

    def growth_text(value):
        value = str(value).strip()
        if not value or value == "No data" or value.startswith("+") or value.startswith("-"):
            return value
        return f"+{value}"

    def draw_logo():
        if not logo_path.exists():
            return
        try:
            if Image is not None:
                img = Image.open(logo_path)
                ratio = img.width / img.height
            else:
                ratio = 4.0
            logo_h = 1.15 * cm
            logo_w = logo_h * ratio
            max_w = 7.2 * cm
            if logo_w > max_w:
                logo_w = max_w
                logo_h = logo_w / ratio
            x = W - 1.2 * cm - logo_w
            y = H - 1.7 * cm
            c.drawImage(ImageReader(str(logo_path)), x, y, width=logo_w, height=logo_h, mask="auto")
        except Exception:
            return

    def draw_header(header_title, subtitle):
        c.setFillColor(navy)
        c.rect(0, H - 2.2 * cm, W, 2.2 * cm, fill=1, stroke=0)
        label(header_title, 1.2 * cm, H - 1.0 * cm, 22, colors.white, True)
        label(subtitle, 1.2 * cm, H - 1.55 * cm, 10, colors.HexColor("#D9F3F7"))
        draw_logo()

    # Page 1
    draw_header(title, "Visual dashboard" + (f" | Reporting period: {period}" if period else ""))

    total_views = sum(s[1] for s in schools)
    total_clicks = sum(s[3] for s in schools)
    top_view = max(schools, key=lambda x: x[1])
    top_click = max(schools, key=lambda x: x[3])

    summary = [
        ("Total schools", str(len(schools)), "Included in this report"),
        ("Total views", fmt(total_views), f"Highest: {top_view[0]}"),
        ("Total clicks", fmt(total_clicks), f"Highest: {top_click[0]}"),
        ("Avg. clicks / school", fmt(round(total_clicks / len(schools))), "Engagement indicator"),
    ]

    sx = 1.2 * cm
    sy = H - 4.0 * cm
    card_w = (W - 2.4 * cm - 0.9 * cm) / 4
    card_h = 1.35 * cm
    for i, (t, v, sub) in enumerate(summary):
        x = sx + i * (card_w + 0.3 * cm)
        rounded_rect(x, sy, card_w, card_h, colors.white, line, 8)
        label(t, x + 0.25 * cm, sy + 0.95 * cm, 8, grey, True)
        label(v, x + 0.25 * cm, sy + 0.45 * cm, 18, navy, True)
        label(sub, x + 0.25 * cm, sy + 0.15 * cm, 7.5, grey)

    section_y = H - 5.25 * cm

    # Left: views
    label("Visibility: views by school", 1.2 * cm, section_y, 13, navy, True)
    label("Longer bars show stronger website visibility.", 1.2 * cm, section_y - 0.42 * cm, 8.5, grey)

    top_sorted = sorted(schools, key=lambda x: x[1], reverse=True)
    max_views = max(s[1] for s in schools) or 1
    x0 = 1.2 * cm
    y0 = section_y - 1.0 * cm
    bar_w = 11.2 * cm
    row_h = 0.62 * cm
    for i, s in enumerate(top_sorted):
        name, views, _vg, _clicks, _cg = s
        y = y0 - i * row_h
        label(name, x0, y + 0.09 * cm, 8, dark, True)
        rounded_rect(x0 + 1.45 * cm, y, bar_w, 0.32 * cm, bar_bg, None, 4)
        rounded_rect(x0 + 1.45 * cm, y, bar_w * views / max_views, 0.32 * cm, teal if i < 5 else colors.HexColor("#A7DDE5"), None, 4)
        label(fmt(views), x0 + 1.45 * cm + bar_w + 0.25 * cm, y + 0.08 * cm, 8, dark, True)

    # Right: clicks. Keep title/subtitle clear; tiles start with explicit clearance.
    right_x = 16.1 * cm
    label("Engagement: clicks by school", right_x, section_y, 13, navy, True)
    label("Cards highlight click volume and growth for every school.", right_x, section_y - 0.42 * cm, 8.5, grey)

    click_sorted = sorted(schools, key=lambda x: x[3], reverse=True)
    max_clicks = max(s[3] for s in schools) or 1
    mini_w = 3.75 * cm
    mini_h = 1.44 * cm
    gap_x = 0.28 * cm
    gap_y = 0.20 * cm
    start_y = section_y - 2.35 * cm
    for idx, s in enumerate(click_sorted):
        col = idx % 3
        row = idx // 3
        x = right_x + col * (mini_w + gap_x)
        y = start_y - row * (mini_h + gap_y)
        name, _views, _vg, clicks, cg = s
        fill = teal_soft if idx < 5 else colors.white
        rounded_rect(x, y, mini_w, mini_h, fill, line, 7)
        label(name, x + 0.18 * cm, y + 1.08 * cm, 8, navy, True)
        label(fmt(clicks), x + 0.18 * cm, y + 0.52 * cm, 16, dark, True)
        label("clicks", x + 0.18 * cm, y + 0.26 * cm, 7, grey)
        rounded_rect(x + 0.18 * cm, y + 0.12 * cm, mini_w - 0.36 * cm, 0.11 * cm, colors.HexColor("#E5EAF0"), None, 3)
        rounded_rect(x + 0.18 * cm, y + 0.12 * cm, (mini_w - 0.36 * cm) * clicks / max_clicks, 0.11 * cm, gold if idx < 5 else gold_soft, None, 3)
        label(growth_text(cg), x + mini_w - 0.18 * cm, y + 1.08 * cm, 6.8, growth_color(cg), False, "right")

    # Key takeaways; no note 4 unless provided.
    bottom_y = 0.95 * cm
    rounded_rect(1.2 * cm, bottom_y, W - 2.4 * cm, 1.25 * cm, light_grey, line, 9)
    label("Key takeaways", 1.55 * cm, bottom_y + 0.82 * cm, 10, navy, True)
    takeaways = [
        f"{top_view[0]} leads views ({fmt(top_view[1])}) and {top_click[0]} leads clicks ({fmt(top_click[3])}).",
        "TMPS has the strongest reported click growth at 820.0%.",
        "PPS and JCPS show consistently strong growth trends.",
    ]
    if takeaway_4:
        takeaways.append(takeaway_4)
    positions = [
        (1.55 * cm, bottom_y + 0.45 * cm),
        (1.55 * cm, bottom_y + 0.10 * cm),
        (W / 2 + 0.4 * cm, bottom_y + 0.45 * cm),
        (W / 2 + 0.4 * cm, bottom_y + 0.10 * cm),
    ]
    for i, t in enumerate(takeaways[:4]):
        x, y = positions[i]
        label(f"{i + 1}. {t}", x, y, 7.8, dark)

    label(f"Source: {source_label}", W - 1.2 * cm, 0.35 * cm, 7, grey, False, "right")
    c.showPage()

    # Page 2
    draw_header("School Scorecard View", "Designed for quick reading: one card per school, no data table.")

    cols = 5
    card_w = (W - 2.4 * cm - (cols - 1) * 0.35 * cm) / cols
    card_h = 4.0 * cm
    start_x = 1.2 * cm
    start_y = H - 2.4 * cm - card_h
    for idx, s in enumerate(schools):
        col = idx % cols
        row = idx // cols
        x = start_x + col * (card_w + 0.35 * cm)
        y = start_y - row * (card_h + 0.42 * cm)
        name, views, vg, clicks, cg = s
        rounded_rect(x, y, card_w, card_h, colors.white, line, 9)
        c.setFillColor(navy if views >= 2000 else colors.HexColor("#5B7894"))
        c.roundRect(x, y + card_h - 0.75 * cm, card_w, 0.75 * cm, 9, fill=1, stroke=0)
        c.rect(x, y + card_h - 0.38 * cm, card_w, 0.38 * cm, fill=1, stroke=0)
        label(name, x + 0.25 * cm, y + card_h - 0.48 * cm, 11, colors.white, True)

        label("Views", x + 0.25 * cm, y + 2.55 * cm, 7.5, grey, True)
        label(fmt(views), x + 0.25 * cm, y + 2.1 * cm, 15, dark, True)
        label(growth_text(vg), x + card_w - 0.25 * cm, y + 2.16 * cm, 7, growth_color(vg, True), False, "right")
        rounded_rect(x + 0.25 * cm, y + 1.78 * cm, card_w - 0.5 * cm, 0.15 * cm, bar_bg, None, 3)
        rounded_rect(x + 0.25 * cm, y + 1.78 * cm, (card_w - 0.5 * cm) * views / max_views, 0.15 * cm, teal, None, 3)

        label("Clicks", x + 0.25 * cm, y + 1.20 * cm, 7.5, grey, True)
        label(fmt(clicks), x + 0.25 * cm, y + 0.75 * cm, 15, dark, True)
        label(growth_text(cg), x + card_w - 0.25 * cm, y + 0.81 * cm, 7, growth_color(cg), False, "right")
        rounded_rect(x + 0.25 * cm, y + 0.43 * cm, card_w - 0.5 * cm, 0.15 * cm, bar_bg, None, 3)
        rounded_rect(x + 0.25 * cm, y + 0.43 * cm, (card_w - 0.5 * cm) * clicks / max_clicks, 0.15 * cm, gold, None, 3)

    label(f"Source: {source_label}", W - 1.2 * cm, 0.35 * cm, 7, grey, False, "right")
    c.save()


def main():
    if len(sys.argv) != 3:
        print("Usage: python create_visual_report.py input.json output.pdf")
        sys.exit(1)
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    data = json.loads(input_path.read_text())
    draw_report(data, output_path)
    print(f"Created {output_path}")


if __name__ == "__main__":
    main()
