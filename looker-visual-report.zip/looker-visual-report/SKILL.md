---
name: looker-visual-report
description: "create a polished visual dashboard pdf from an uploaded looker studio school website activity report. use when the user uploads a looker studio pdf or screenshot containing scorecards for school views/clicks and asks to make it professional, visual, dashboard-style, readable, not table-based, or similar. preserve the standard design exactly: dark navy header with the bundled ict365 logo, summary cards, views bars on the left, click engagement cards on the right, no overlapping text, no dense tables, and a second page of school scorecards."
---

# Looker Visual Report

## Purpose

Create a professional, visual PDF dashboard from a Looker Studio school website activity report. The standard output is a two-page visual report using scorecards and bar indicators, not a table.

## Workflow

1. Read the uploaded Looker Studio report PDF or image.
2. Extract each school code, views, view growth, clicks, and click growth from the uploaded report.
3. Confirm the reporting period from the report header if visible.
4. Build an input JSON file matching the structure below.
5. Run `scripts/create_visual_report.py input.json output.pdf`.
6. Render-check the PDF if possible before returning it. Verify that the engagement subtitle is not covered by the first row of tiles.
7. Return the generated PDF as a download link.

## Fixed Design Standard

Always use the bundled `assets/ict365-logo.png` in the right side of the dark navy header.

Use this exact layout:

- Page 1 is the executive dashboard.
  - Dark navy header with title/subtitle on the left and ICT365 logo on the right.
  - Summary cards below the header.
  - Views/visibility horizontal bars on the left.
  - Click engagement cards on the right.
  - The click section title and explanatory subtitle must remain fully visible. Start the first row of tiles lower than the subtitle; do not cover the subtitle.
  - Key takeaways at the bottom.
- Page 2 is the scorecard view.
  - One card per school.
  - Each card includes views, view growth, clicks, click growth, and mini bar indicators.

Do not move clicks above views or replace the layout with one large tile grid. The report must keep views on the left and clicks on the right on page 1.

## Notes and Takeaways

Use three default takeaways unless the user asks for different wording:

1. The top-view school and top-click school lead overall performance.
2. TMPS has the strongest reported click growth when its click growth remains 820.0%.
3. PPS and JCPS show consistently strong growth trends when that is supported by the uploaded report.

Only include a fourth note when the uploaded report actually contains missing/no-data click growth values. If the current uploaded report includes click data/growth for MMPS, LSHS and WEPS, do not include note 4.

If a fourth note is needed for an older report with missing click-growth data, use this exact wording unless the user requests otherwise:

`No data: LHS, MMPS (Analytics introduced April 2026); WEPS has consistently high user interaction.`

## Data Input Format for Script

Create a JSON file with this structure:

```json
{
  "title": "Schools Website Activity Report",
  "period": "Dec 31, 2025 - May 22, 2026",
  "source_label": "Uploaded Looker Studio report",
  "takeaway_4": "",
  "schools": [
    {"school": "CHHS", "views": 4542, "view_growth": "709.6%", "clicks": 1365, "click_growth": "417.0%"}
  ]
}
```

Set `takeaway_4` to an empty string when the current report has full click data for MMPS, LSHS and WEPS.

Then run:

```bash
python scripts/create_visual_report.py input.json output.pdf
```

## Handling User Edits

When the user requests layout or wording edits, regenerate the PDF directly. Common fixes:

- If a tile overlaps the engagement subtitle, increase `tiles_start_y` clearance in the script or reduce tile height/gap.
- If the user asks for the original design, keep views on the left and clicks on the right.
- If note wording is changed, update the takeaway text exactly as requested.
- If the user asks for a more visual display, keep scorecards and bars rather than converting to a table.

## Output

Always provide the final PDF as a downloadable file. Briefly state what was changed.
